Overview(Exercise2)

The Real-time Chat Application is a Java-based console program that simulates a chat system where users can create or join chat rooms, add participants dynamically, and view a list of active users in each room.

The project is built using Object-Oriented Programming principles and is designed to be extensible with software design patterns such as:

Observer Pattern – for real-time message broadcasting to all users in a chat room.

Singleton Pattern – for centralized chat room management.

Adapter Pattern – for supporting multiple communication protocols (e.g., WebSocket, HTTP).

Currently, the system provides chat room and user management through console input/output, and lays the foundation for advanced features like real-time messaging, message history, and private conversations.